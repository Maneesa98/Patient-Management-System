package com.xadmin.patientreg.model;

public class User {
	protected int id;
	protected String name;
	protected int mobile;
	protected String disease;
	
	public User() {
	}
	
	public User(String name, int mobile, String disease) {
		super();
		this.name = name;
		this.mobile = mobile;
		this.disease = disease;
	}

	public User(int id, String name, int mobile, String disease) {
		super();
		this.id = id;
		this.name = name;
		this.mobile = mobile;
		this.disease = disease;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public String getDisease() {
		return disease;
	}
	public void setDisease(String disease) {
		this.disease = disease;
	}
}